print( __name__, type(__name__) )

# __name__은 2가지 값으로 변경된다
# 이것을 이용해 유기적인 코드를 
# 작성할수 있다 (선택적 코드 진행)
# __main__ <class 'str'>
# test6 <class 'str'>